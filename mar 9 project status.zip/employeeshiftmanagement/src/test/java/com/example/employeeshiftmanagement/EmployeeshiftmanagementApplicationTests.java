package com.example.employeeshiftmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeshiftmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
