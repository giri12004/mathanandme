package com.example.employeeshiftmanagement.repository;

import com.example.employeeshiftmanagement.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface EmployeeRepository extends JpaRepository<Employee, UUID> {

    // Custom query to find an employee by user ID
    @Query("SELECT e FROM Employee e WHERE e.user.userId = :userId")
    Employee findEmployeeByUserId(@Param("userId") UUID userId);

    // Get all employees in a department
    @Query("SELECT e FROM Employee e WHERE e.department = :department")
    List<Employee> findEmployeesByDepartment(@Param("department") String department);

    // Check if employee exists by employeeId
    @Query("SELECT COUNT(e) > 0 FROM Employee e WHERE e.employeeId = :employeeId")
    boolean existsByEmployeeId(@Param("employeeId") UUID employeeId);
}
