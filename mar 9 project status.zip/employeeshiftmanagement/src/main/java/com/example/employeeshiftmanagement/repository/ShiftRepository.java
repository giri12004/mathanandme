package com.example.employeeshiftmanagement.repository;

import com.example.employeeshiftmanagement.entity.Shift;
import com.example.employeeshiftmanagement.enums.ShiftType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface ShiftRepository extends JpaRepository<Shift, UUID> {

    // Custom query to find all shifts by shift type
    @Query("SELECT s FROM Shift s WHERE s.shiftType = :shiftType")
    List<Shift> findShiftsByShiftType(@Param("shiftType") ShiftType shiftType);

    // Find shifts created by a specific manager
    @Query("SELECT s FROM Shift s WHERE s.createdBy.userId = :managerId")
    List<Shift> findShiftsByManagerId(@Param("managerId") UUID managerId);
}
