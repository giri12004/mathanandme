package com.example.employeeshiftmanagement.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "employee_shifts")
public class EmployeeShift {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID employeeShiftId;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @ManyToOne
    @JoinColumn(name = "shift_id", nullable = false)
    private Shift shift;

    @Column(nullable = false)
    private LocalDate assignedDate;

    public EmployeeShift() {}

    public EmployeeShift(Employee employee, Shift shift, LocalDate assignedDate) {
        this.employee = employee;
        this.shift = shift;
        this.assignedDate = assignedDate;
    }

    public UUID getEmployeeShiftId() {
        return employeeShiftId;
    }

    public void setEmployeeShiftId(UUID employeeShiftId) {
        this.employeeShiftId = employeeShiftId;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Shift getShift() {
        return shift;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

    public LocalDate getAssignedDate() {
        return assignedDate;
    }

    public void setAssignedDate(LocalDate assignedDate) {
        this.assignedDate = assignedDate;
    }
}
