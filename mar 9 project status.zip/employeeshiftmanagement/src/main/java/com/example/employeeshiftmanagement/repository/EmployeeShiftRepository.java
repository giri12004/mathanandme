package com.example.employeeshiftmanagement.repository;

import com.example.employeeshiftmanagement.entity.EmployeeShift;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface EmployeeShiftRepository extends JpaRepository<EmployeeShift, UUID> {

    // Find all shifts assigned to a specific employee
    @Query("SELECT es FROM EmployeeShift es WHERE es.employee.employeeId = :employeeId")
    List<EmployeeShift> findShiftsByEmployeeId(@Param("employeeId") UUID employeeId);

    // Check if a shift is already assigned to an employee
    @Query("SELECT COUNT(es) > 0 FROM EmployeeShift es WHERE es.employee.employeeId = :employeeId AND es.shift.shiftId = :shiftId")
    boolean existsByEmployeeAndShift(@Param("employeeId") UUID employeeId, @Param("shiftId") UUID shiftId);
}
