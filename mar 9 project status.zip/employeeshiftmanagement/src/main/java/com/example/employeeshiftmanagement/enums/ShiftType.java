package com.example.employeeshiftmanagement.enums;

public enum ShiftType {
    MORNING,
    AFTERNOON,
    NIGHT
}
