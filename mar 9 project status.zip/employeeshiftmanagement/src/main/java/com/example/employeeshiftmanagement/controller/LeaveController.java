package com.example.employeeshiftmanagement.controller;

import com.example.employeeshiftmanagement.dto.LeaveDTO;
import com.example.employeeshiftmanagement.dto.LeaveRequestDTO;
import com.example.employeeshiftmanagement.entity.Leave;
import com.example.employeeshiftmanagement.enums.LeaveStatus;
import com.example.employeeshiftmanagement.service.LeaveService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/leaves")
public class LeaveController {

    private final LeaveService leaveService;

    public LeaveController(LeaveService leaveService) {
        this.leaveService = leaveService;
    }

    @PostMapping
    public ResponseEntity<Leave> applyLeave(@RequestBody LeaveRequestDTO leaveRequestDTO) {
        Leave leave = leaveService.applyLeave(leaveRequestDTO);
        return new ResponseEntity<>(leave, HttpStatus.CREATED);
    }

    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<LeaveDTO>> getLeavesByEmployee(@PathVariable UUID employeeId) {
        List<LeaveDTO> leaves = leaveService.getLeavesByEmployee(employeeId);
        return new ResponseEntity<>(leaves, HttpStatus.OK);
    }

    @PutMapping("/{leaveId}/status")
    public ResponseEntity<Leave> updateLeaveStatus(
            @PathVariable UUID leaveId,
            @RequestParam LeaveStatus status,
            @RequestParam(required = false) String rejectionReason) {
        Leave updatedLeave = leaveService.updateLeaveStatus(leaveId, status, rejectionReason);
        return new ResponseEntity<>(updatedLeave, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<LeaveDTO>> getAllLeaves() {
        List<LeaveDTO> leaves = leaveService.getAllLeaves();
        return new ResponseEntity<>(leaves, HttpStatus.OK);
    }

    @DeleteMapping("/{leaveId}")
    public ResponseEntity<Void> deleteLeave(@PathVariable UUID leaveId) {
        leaveService.deleteLeave(leaveId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}