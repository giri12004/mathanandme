package com.example.employeeshiftmanagement.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.UUID;

public class AttendanceDTO {

    private UUID employeeId;
    private LocalTime checkInTime;
    private LocalTime checkOutTime;
    private LocalDate attendanceDate;

    // Constructors
    public AttendanceDTO() {}

    public AttendanceDTO(UUID employeeId, LocalTime checkInTime, LocalTime checkOutTime, LocalDate attendanceDate) {
        this.employeeId = employeeId;
        this.checkInTime = checkInTime;
        this.checkOutTime = checkOutTime;
        this.attendanceDate = attendanceDate;
    }

    // Getters and Setters
    public UUID getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(UUID employeeId) {
        this.employeeId = employeeId;
    }

    public LocalTime getCheckInTime() {
        return checkInTime;
    }

    public void setCheckInTime(LocalTime checkInTime) {
        this.checkInTime = checkInTime;
    }

    public LocalTime getCheckOutTime() {
        return checkOutTime;
    }

    public void setCheckOutTime(LocalTime checkOutTime) {
        this.checkOutTime = checkOutTime;
    }

    public LocalDate getAttendanceDate() {
        return attendanceDate;
    }

    public void setAttendanceDate(LocalDate attendanceDate) {
        this.attendanceDate = attendanceDate;
    }
}
