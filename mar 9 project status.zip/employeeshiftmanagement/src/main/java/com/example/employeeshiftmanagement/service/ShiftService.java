package com.example.employeeshiftmanagement.service;

import com.example.employeeshiftmanagement.entity.Shift;
import com.example.employeeshiftmanagement.enums.ShiftType;
import com.example.employeeshiftmanagement.exception.ResourceNotFoundException;
import com.example.employeeshiftmanagement.repository.ShiftRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class ShiftService {

    private final ShiftRepository shiftRepository;

    public ShiftService(ShiftRepository shiftRepository) {
        this.shiftRepository = shiftRepository;
    }

    // Create a shift
    @Transactional
    public Shift createShift(Shift shift) {
        return shiftRepository.save(shift);
    }

    // Fetch shift by ID
    public Shift getShiftById(UUID shiftId) {
        Shift shift = shiftRepository.findById(shiftId).orElse(null);
        if (shift == null) {
            throw new ResourceNotFoundException("Shift not found with ID: " + shiftId);
        }
        return shift;
    }

    // Fetch shifts by shift type
    public List<Shift> getShiftsByType(ShiftType shiftType) {
        return shiftRepository.findShiftsByShiftType(shiftType);
    }

    // Fetch all shifts by manager
    public List<Shift> getShiftsByManager(UUID managerId) {
        return shiftRepository.findShiftsByManagerId(managerId);
    }

    // Delete shift
    @Transactional
    public void deleteShift(UUID shiftId) {
        Shift shift = getShiftById(shiftId);
        shiftRepository.delete(shift);
    }
}
