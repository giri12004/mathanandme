package com.example.employeeshiftmanagement.enums;

public enum Role {
    ADMIN,
    MANAGER,
    EMPLOYEE
}
