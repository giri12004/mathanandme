package com.example.employeeshiftmanagement.service;

import com.example.employeeshiftmanagement.dto.AttendanceDTO;
import com.example.employeeshiftmanagement.entity.Attendance;
import com.example.employeeshiftmanagement.entity.Employee;
import com.example.employeeshiftmanagement.exception.ResourceNotFoundException;
import com.example.employeeshiftmanagement.repository.AttendanceRepository;
import com.example.employeeshiftmanagement.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final EmployeeRepository employeeRepository;

    public AttendanceService(AttendanceRepository attendanceRepository, EmployeeRepository employeeRepository) {
        this.attendanceRepository = attendanceRepository;
        this.employeeRepository = employeeRepository;
    }

    // Mark Check-In
    @Transactional
    public Attendance markCheckIn(AttendanceDTO attendanceDTO) {
        Employee employee = employeeRepository.findById(attendanceDTO.getEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        Attendance attendance = new Attendance();
        attendance.setEmployee(employee);
        attendance.setCheckInTime(attendanceDTO.getCheckInTime());
        attendance.setAttendanceDate(attendanceDTO.getAttendanceDate());

        return attendanceRepository.save(attendance);
    }

    // Mark Check-Out
    @Transactional
    public Attendance markCheckOut(UUID employeeId) {
        Attendance attendance = attendanceRepository.findByEmployeeIdAndDate(employeeId, LocalDate.now())
                .orElseThrow(() -> new ResourceNotFoundException("Attendance record not found"));

        attendance.setCheckOutTime(java.time.LocalTime.now());

        return attendanceRepository.save(attendance);
    }

    // Get Attendance by Employee
    public List<Attendance> getAttendanceByEmployee(UUID employeeId) {
        return attendanceRepository.findAttendanceByEmployeeId(employeeId);
    }

    // Get Attendance for Last 7 Days
    public List<Attendance> getAttendanceForLast7Days(UUID employeeId) {
        LocalDate startDate = LocalDate.now().minusDays(7);
        return attendanceRepository.findAttendanceForLast7Days(employeeId, startDate);
    }

    // Generate Weekly Report
    public List<Attendance> generateWeeklyReport(UUID employeeId, LocalDate startDate) {
        return attendanceRepository.findAttendanceForLast7Days(employeeId, startDate);
    }
}
