package com.example.employeeshiftmanagement.dto;

import java.time.LocalDate;
import java.util.UUID;

public class LeaveRequestDTO {

    private UUID employeeId;
    private LocalDate startDate;
    private LocalDate endDate;
    private String reason;

    // Getters and Setters
    public UUID getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(UUID employeeId) {
        this.employeeId = employeeId;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }
}
