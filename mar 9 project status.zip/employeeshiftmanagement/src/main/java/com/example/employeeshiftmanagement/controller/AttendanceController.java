package com.example.employeeshiftmanagement.controller;

import com.example.employeeshiftmanagement.dto.AttendanceDTO;
import com.example.employeeshiftmanagement.entity.Attendance;
import com.example.employeeshiftmanagement.service.AttendanceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;

    public AttendanceController(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    // Mark Check-In (Employee action)
    @PostMapping("/checkin")
    public ResponseEntity<Attendance> checkIn(@RequestBody AttendanceDTO attendanceDTO) {
        Attendance attendance = attendanceService.markCheckIn(attendanceDTO);
        return new ResponseEntity<>(attendance, HttpStatus.CREATED);
    }

    // Mark Check-Out (Employee action)
    @PutMapping("/checkout")
    public ResponseEntity<Attendance> checkOut(@RequestParam UUID employeeId) {
        Attendance attendance = attendanceService.markCheckOut(employeeId);
        return new ResponseEntity<>(attendance, HttpStatus.OK);
    }

    // Get Attendance for an Employee (Employee/Manager/Admin view)
    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<Attendance>> getAttendanceByEmployee(@PathVariable UUID employeeId) {
        List<Attendance> attendanceRecords = attendanceService.getAttendanceByEmployee(employeeId);
        return new ResponseEntity<>(attendanceRecords, HttpStatus.OK);
    }

    // Get Attendance for the Last 7 Days
    @GetMapping("/last7days/{employeeId}")
    public ResponseEntity<List<Attendance>> getAttendanceForLast7Days(@PathVariable UUID employeeId) {
        List<Attendance> attendanceRecords = attendanceService.getAttendanceForLast7Days(employeeId);
        return new ResponseEntity<>(attendanceRecords, HttpStatus.OK);
    }

    // Generate Weekly Attendance Report (Employee action)
    @GetMapping("/report/weekly/{employeeId}")
    public ResponseEntity<List<Attendance>> generateWeeklyReport(
            @PathVariable UUID employeeId,
            @RequestParam LocalDate startDate) {
        List<Attendance> weeklyReport = attendanceService.generateWeeklyReport(employeeId, startDate);
        return new ResponseEntity<>(weeklyReport, HttpStatus.OK);
    }
}
