package com.example.employeeshiftmanagement.service;

import com.example.employeeshiftmanagement.dto.LeaveRequestDTO;
import com.example.employeeshiftmanagement.entity.Leave;
import com.example.employeeshiftmanagement.enums.LeaveStatus;
import com.example.employeeshiftmanagement.repository.LeaveRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class LeaveService {

    private final LeaveRepository leaveRepository;

    public LeaveService(LeaveRepository leaveRepository) {
        this.leaveRepository = leaveRepository;
    }

    @Transactional
    public Leave applyLeave(LeaveRequestDTO leaveRequestDTO) {
        Leave leave = new Leave(leaveRequestDTO.getEmployee(), leaveRequestDTO.getStartDate(), leaveRequestDTO.getEndDate(), LeaveStatus.PENDING, leaveRequestDTO.getReason());
        return leaveRepository.save(leave);
    }

    public List<Leave> getLeavesByEmployee(UUID employeeId) {
        return leaveRepository.findLeavesByEmployeeId(employeeId);
    }

    public Leave updateLeaveStatus(UUID leaveId, LeaveStatus status, String reason) {
        Leave leave = leaveRepository.findById(leaveId).orElseThrow(() -> new RuntimeException("Leave not found"));
        leave.setStatus(status);
        if (status == LeaveStatus.REJECTED) {
            leave.setRejectionReason(reason);
        }
        return leaveRepository.save(leave);
    }

    public List<Leave> getAllLeaves() {
        return leaveRepository.findAll();
    }

    @Transactional
    public void deleteLeave(UUID leaveId) {
        Leave leave = leaveRepository.findById(leaveId).orElseThrow(() -> new RuntimeException("Leave not found"));
        if (leave.getStatus() != LeaveStatus.PENDING) {
            throw new IllegalStateException("Only pending leave requests can be deleted.");
        }
        leaveRepository.delete(leave);
    }
}