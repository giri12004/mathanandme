package com.example.employeeshiftmanagement.enums;

public enum NotificationStatus {
    UNREAD,
    READ
}
