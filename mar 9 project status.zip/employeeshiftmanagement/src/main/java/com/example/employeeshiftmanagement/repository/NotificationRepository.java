package com.example.employeeshiftmanagement.repository;

import com.example.employeeshiftmanagement.entity.Notification;
import com.example.employeeshiftmanagement.enums.NotificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface NotificationRepository extends JpaRepository<Notification, UUID> {

    // Find notifications by user ID
    @Query("SELECT n FROM Notification n WHERE n.user.userId = :userId")
    List<Notification> findNotificationsByUserId(@Param("userId") UUID userId);

    // Find unread notifications by user ID
    @Query("SELECT n FROM Notification n WHERE n.user.userId = :userId AND n.status = 'UNREAD'")
    List<Notification> findUnreadNotificationsByUserId(@Param("userId") UUID userId);

    // Mark notification as read
    @Query("UPDATE Notification n SET n.status = :status WHERE n.notificationId = :notificationId")
    void updateNotificationStatus(@Param("notificationId") UUID notificationId, @Param("status") NotificationStatus status);

	Notification findNotificationById(UUID notificationId);
}
