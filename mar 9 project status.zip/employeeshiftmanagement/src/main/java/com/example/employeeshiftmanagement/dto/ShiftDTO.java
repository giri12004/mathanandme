package com.example.employeeshiftmanagement.dto;

import com.example.employeeshiftmanagement.enums.ShiftType;

import java.util.UUID;

public class ShiftDTO {

    private UUID shiftId;
    private String department;
    private String startTime;
    private String endTime;
    private ShiftType shiftType;
    private UUID createdBy;

    // Constructors
    public ShiftDTO() {}

    public ShiftDTO(UUID shiftId, String department, String startTime, String endTime, ShiftType shiftType, UUID createdBy) {
        this.shiftId = shiftId;
        this.department = department;
        this.startTime = startTime;
        this.endTime = endTime;
        this.shiftType = shiftType;
        this.createdBy = createdBy;
    }

    // Getters and Setters
    public UUID getShiftId() {
        return shiftId;
    }

    public void setShiftId(UUID shiftId) {
        this.shiftId = shiftId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public ShiftType getShiftType() {
        return shiftType;
    }

    public void setShiftType(ShiftType shiftType) {
        this.shiftType = shiftType;
    }

    public UUID getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(UUID createdBy) {
        this.createdBy = createdBy;
    }
}
