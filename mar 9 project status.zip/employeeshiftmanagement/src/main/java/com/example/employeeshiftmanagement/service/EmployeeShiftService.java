package com.example.employeeshiftmanagement.service;

import com.example.employeeshiftmanagement.entity.EmployeeShift;
import com.example.employeeshiftmanagement.exception.ResourceNotFoundException;
import com.example.employeeshiftmanagement.repository.EmployeeShiftRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class EmployeeShiftService {

    private final EmployeeShiftRepository employeeShiftRepository;

    public EmployeeShiftService(EmployeeShiftRepository employeeShiftRepository) {
        this.employeeShiftRepository = employeeShiftRepository;
    }

    // Assign shift to an employee
    @Transactional
    public EmployeeShift assignShift(EmployeeShift employeeShift) {
        return employeeShiftRepository.save(employeeShift);
    }

    // Fetch employee shifts by employeeId
    public List<EmployeeShift> getShiftsByEmployee(UUID employeeId) {
        return employeeShiftRepository.findShiftsByEmployeeId(employeeId);
    }

    // Delete shift assignment
    @Transactional
    public void deleteEmployeeShift(UUID employeeShiftId) {
        EmployeeShift employeeShift = employeeShiftRepository.findById(employeeShiftId).orElse(null);
        if (employeeShift == null) {
            throw new ResourceNotFoundException("Employee Shift not found with ID: " + employeeShiftId);
        }
        employeeShiftRepository.delete(employeeShift);
    }
}
