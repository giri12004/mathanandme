package com.example.employeeshiftmanagement.enums;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
