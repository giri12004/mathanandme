package com.example.employeeshiftmanagement.controller;

import com.example.employeeshiftmanagement.dto.ShiftDTO;
import com.example.employeeshiftmanagement.entity.Shift;
import com.example.employeeshiftmanagement.service.ShiftService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/shifts")
public class ShiftController {

    private final ShiftService shiftService;

    public ShiftController(ShiftService shiftService) {
        this.shiftService = shiftService;
    }

    // Create a Shift (Manager action)
    @PostMapping
    public ResponseEntity<Shift> createShift(@RequestBody ShiftDTO shiftDTO) {
        Shift createdShift = shiftService.createShift(shiftDTO);
        return new ResponseEntity<>(createdShift, HttpStatus.CREATED);
    }

    // Get all Shifts
    @GetMapping
    public ResponseEntity<List<Shift>> getAllShifts() {
        List<Shift> shifts = shiftService.getAllShifts();
        return new ResponseEntity<>(shifts, HttpStatus.OK);
    }

    // Get Shift by ID
    @GetMapping("/{shiftId}")
    public ResponseEntity<Shift> getShiftById(@PathVariable UUID shiftId) {
        Shift shift = shiftService.getShiftById(shiftId);
        return new ResponseEntity<>(shift, HttpStatus.OK);
    }

    // Delete a Shift (Manager action)
    @DeleteMapping("/{shiftId}")
    public ResponseEntity<Void> deleteShift(@PathVariable UUID shiftId) {
        shiftService.deleteShift(shiftId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
