package com.example.employeeshiftmanagement.service;

import com.example.employeeshiftmanagement.entity.Notification;
import com.example.employeeshiftmanagement.exception.ResourceNotFoundException;
import com.example.employeeshiftmanagement.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    // Create a notification (Internal use)
    @Transactional
    public Notification createNotification(UUID userId, String message) {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setMessage(message);
        return notificationRepository.save(notification);
    }

    // Get notifications for a specific user
    public List<Notification> getUserNotifications(UUID userId) {
        return notificationRepository.findNotificationsByUserId(userId);
    }

    // Mark notification as read
    @Transactional
    public Notification markAsRead(UUID notificationId) {
        Notification notification = notificationRepository.findNotificationById(notificationId);
        if (notification == null) {
            throw new ResourceNotFoundException("Notification not found with ID: " + notificationId);
        }

        notification.setRead(true);
        return notificationRepository.save(notification);
    }

    // Delete notification
    @Transactional
    public void deleteNotification(UUID notificationId) {
        Notification notification = notificationRepository.findNotificationById(notificationId);
        if (notification == null) {
            throw new ResourceNotFoundException("Notification not found with ID: " + notificationId);
        }
        notificationRepository.delete(notification);
    }
}
