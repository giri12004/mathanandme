package com.example.employeeshiftmanagement.controller;

import com.example.employeeshiftmanagement.dto.EmployeeShiftDTO;
import com.example.employeeshiftmanagement.entity.EmployeeShift;
import com.example.employeeshiftmanagement.service.EmployeeShiftService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/employee-shifts")
public class EmployeeShiftController {

    private final EmployeeShiftService employeeShiftService;

    public EmployeeShiftController(EmployeeShiftService employeeShiftService) {
        this.employeeShiftService = employeeShiftService;
    }

    // Assign Shift to Employee (Manager Action)
    @PostMapping
    public ResponseEntity<EmployeeShift> assignShift(@RequestBody EmployeeShiftDTO employeeShiftDTO) {
        EmployeeShift employeeShift = employeeShiftService.assignShift(employeeShiftDTO);
        return new ResponseEntity<>(employeeShift, HttpStatus.CREATED);
    }

    // Update Shift Assignment (Manager Action)
    @PutMapping("/{shiftAssignmentId}")
    public ResponseEntity<EmployeeShift> updateShiftAssignment(
            @PathVariable UUID shiftAssignmentId,
            @RequestBody EmployeeShiftDTO employeeShiftDTO) {
        EmployeeShift updatedShift = employeeShiftService.updateShiftAssignment(shiftAssignmentId, employeeShiftDTO);
        return new ResponseEntity<>(updatedShift, HttpStatus.OK);
    }

    // Get Assigned Shifts for an Employee (Employee View)
    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<EmployeeShift>> getShiftsByEmployee(@PathVariable UUID employeeId) {
        List<EmployeeShift> shifts = employeeShiftService.getShiftsByEmployee(employeeId);
        return new ResponseEntity<>(shifts, HttpStatus.OK);
    }

    // Get All Shift Assignments (Admin/Manager View)
    @GetMapping
    public ResponseEntity<List<EmployeeShift>> getAllShiftAssignments() {
        List<EmployeeShift> allShifts = employeeShiftService.getAllShiftAssignments();
        return new ResponseEntity<>(allShifts, HttpStatus.OK);
    }

    // Delete Shift Assignment (Manager Action)
    @DeleteMapping("/{shiftAssignmentId}")
    public ResponseEntity<String> deleteShiftAssignment(@PathVariable UUID shiftAssignmentId) {
        employeeShiftService.deleteShiftAssignment(shiftAssignmentId);
        return new ResponseEntity<>("Shift assignment deleted successfully.", HttpStatus.OK);
    }
}
