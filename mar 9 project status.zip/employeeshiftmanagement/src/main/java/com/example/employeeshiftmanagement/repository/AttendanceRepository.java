package com.example.employeeshiftmanagement.repository;

import com.example.employeeshiftmanagement.entity.Attendance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AttendanceRepository extends JpaRepository<Attendance, UUID> {

    // Find attendance by employee ID and date
    @Query("SELECT a FROM Attendance a WHERE a.employee.employeeId = :employeeId AND a.attendanceDate = :date")
    Optional<Attendance> findByEmployeeIdAndDate(@Param("employeeId") UUID employeeId, @Param("date") LocalDate date);

    // Find all attendance records for an employee
    @Query("SELECT a FROM Attendance a WHERE a.employee.employeeId = :employeeId")
    List<Attendance> findAttendanceByEmployeeId(@Param("employeeId") UUID employeeId);

    // Find attendance records for the last 7 days
    @Query("SELECT a FROM Attendance a WHERE a.employee.employeeId = :employeeId AND a.attendanceDate >= :startDate")
    List<Attendance> findAttendanceForLast7Days(@Param("employeeId") UUID employeeId, @Param("startDate") LocalDate startDate);

    // Find attendance records within a date range for a weekly report
    @Query("SELECT a FROM Attendance a WHERE a.employee.employeeId = :employeeId AND a.attendanceDate BETWEEN :startDate AND :endDate")
    List<Attendance> findWeeklyAttendance(@Param("employeeId") UUID employeeId, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    // Find the latest attendance record for a specific employee
    @Query("SELECT a FROM Attendance a WHERE a.employee.employeeId = :employeeId ORDER BY a.attendanceDate DESC LIMIT 1")
    Optional<Attendance> findLatestAttendanceByEmployeeId(@Param("employeeId") UUID employeeId);
}