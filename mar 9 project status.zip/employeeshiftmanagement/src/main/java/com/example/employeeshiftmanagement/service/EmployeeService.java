package com.example.employeeshiftmanagement.service;

import com.example.employeeshiftmanagement.entity.Employee;
import com.example.employeeshiftmanagement.exception.ResourceNotFoundException;
import com.example.employeeshiftmanagement.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // Create new employee
    @Transactional
    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    // Fetch employee by userId
    public Employee getEmployeeByUserId(UUID userId) {
        Employee employee = employeeRepository.findEmployeeByUserId(userId);
        if (employee == null) {
            throw new ResourceNotFoundException("Employee not found for userId: " + userId);
        }
        return employee;
    }

    // Update employee details
    @Transactional
    public Employee updateEmployee(UUID employeeId, Employee updatedEmployee) {
        Employee existingEmployee = getEmployeeById(employeeId);
        existingEmployee.setDepartment(updatedEmployee.getDepartment());
        existingEmployee.setPosition(updatedEmployee.getPosition());
        return employeeRepository.save(existingEmployee);
    }

    // Fetch by employeeId
    public Employee getEmployeeById(UUID employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElse(null);
        if (employee == null) {
            throw new ResourceNotFoundException("Employee not found with ID: " + employeeId);
        }
        return employee;
    }

    // Delete employee
    @Transactional
    public void deleteEmployee(UUID employeeId) {
        Employee employee = getEmployeeById(employeeId);
        employeeRepository.delete(employee);
    }

    // Fetch employees by department
    public List<Employee> getEmployeesByDepartment(String department) {
        return employeeRepository.findEmployeesByDepartment(department);
    }
}
