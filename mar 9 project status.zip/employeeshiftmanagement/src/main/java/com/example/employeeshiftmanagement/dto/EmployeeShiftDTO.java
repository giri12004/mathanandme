package com.example.employeeshiftmanagement.dto;

import java.time.LocalDate;
import java.util.UUID;

public class EmployeeShiftDTO {

    private UUID employeeId;
    private UUID shiftId;
    private LocalDate shiftDate;
    private UUID assignedBy;

    // Constructors
    public EmployeeShiftDTO() {}

    public EmployeeShiftDTO(UUID employeeId, UUID shiftId, LocalDate shiftDate, UUID assignedBy) {
        this.employeeId = employeeId;
        this.shiftId = shiftId;
        this.shiftDate = shiftDate;
        this.assignedBy = assignedBy;
    }

    // Getters and Setters
    public UUID getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(UUID employeeId) {
        this.employeeId = employeeId;
    }

    public UUID getShiftId() {
        return shiftId;
    }

    public void setShiftId(UUID shiftId) {
        this.shiftId = shiftId;
    }

    public LocalDate getShiftDate() {
        return shiftDate;
    }

    public void setShiftDate(LocalDate shiftDate) {
        this.shiftDate = shiftDate;
    }

    public UUID getAssignedBy() {
        return assignedBy;
    }

    public void setAssignedBy(UUID assignedBy) {
        this.assignedBy = assignedBy;
    }
}
