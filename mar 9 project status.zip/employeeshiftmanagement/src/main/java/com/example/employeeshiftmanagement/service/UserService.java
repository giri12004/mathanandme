package com.example.employeeshiftmanagement.service;

import com.example.employeeshiftmanagement.entity.User;
import com.example.employeeshiftmanagement.enums.Role;
import com.example.employeeshiftmanagement.exception.ResourceNotFoundException;
import com.example.employeeshiftmanagement.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Create a new user (Admin adds Employee/Manager)
    @Transactional
    public User createUser(User user) {
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new IllegalArgumentException("Username already exists.");
        }
        return userRepository.save(user);
    }

    // Fetch user by ID
    public User getUserById(UUID userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            throw new ResourceNotFoundException("User not found with ID: " + userId);
        }
        return user;
    }

    // Fetch user by username
    public User getUserByUsername(String username) {
        User user = userRepository.findUserByUsername(username);
        if (user == null) {
            throw new ResourceNotFoundException("User not found with username: " + username);
        }
        return user;
    }

    // Update user details
    @Transactional
    public User updateUser(UUID userId, User updatedUser) {
        User existingUser = getUserById(userId);
        existingUser.setUsername(updatedUser.getUsername());
        existingUser.setRole(updatedUser.getRole());
        return userRepository.save(existingUser);
    }

    // Delete user
    @Transactional
    public void deleteUser(UUID userId) {
        User user = getUserById(userId);
        userRepository.delete(user);
    }

    // Fetch all users by role
    public List<User> getUsersByRole(Role role) {
        return userRepository.findUsersByRole(role);
    }
}
