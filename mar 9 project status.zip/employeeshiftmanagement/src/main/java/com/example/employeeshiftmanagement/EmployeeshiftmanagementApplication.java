package com.example.employeeshiftmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeshiftmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeshiftmanagementApplication.class, args);
	}

}
