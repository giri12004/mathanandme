package com.example.employeeshiftmanagement.dto;

import java.util.UUID;

public class EmployeeDTO {

    private UUID employeeId;
    private UUID userId;
    private String name;
    private String department;
    private String contactNumber;

    // Constructors
    public EmployeeDTO() {}

    public EmployeeDTO(UUID employeeId, UUID userId, String name, String department, String contactNumber) {
        this.employeeId = employeeId;
        this.userId = userId;
        this.name = name;
        this.department = department;
        this.contactNumber = contactNumber;
    }

    // Getters and Setters
    public UUID getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(UUID employeeId) {
        this.employeeId = employeeId;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }
}
