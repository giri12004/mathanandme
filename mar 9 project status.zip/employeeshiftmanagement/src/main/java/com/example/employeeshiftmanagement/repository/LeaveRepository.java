package com.example.employeeshiftmanagement.repository;

import com.example.employeeshiftmanagement.entity.Leave;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface LeaveRepository extends JpaRepository<Leave, UUID> {
    List<Leave> findLeavesByEmployeeId(UUID employeeId);
}
